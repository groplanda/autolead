<?php return [
    'plugin' => [
        'name' => 'Настройки',
        'description' => ''
    ]
];